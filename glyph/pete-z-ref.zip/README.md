# PETE · Protocol Z Reference (Glyph→Code)

This is a tiny scaffolding repo that demonstrates **Z:S → Z:C** integration with the attached **Glyph code compression (v0.3)**.

## What it shows
- `spec.glyph.md` — the *authoritative* Z:S spec in glyph-block form.
- `build.py` — a tiny compiler shim that turns the glyph block into Python (Z:C output) and auto-annotates with glyph comments.
- `audit.py` — checks that the code conforms to the spec (caps, recovery forms, required anchors).
- `pipeline.py` — generated code (do not hand-edit).
- `tests/` — a microscopic unit test.

## Quick start
```bash
# 1) Generate code from spec (Z:C compilation)
python build.py

# 2) Audit the generated code against spec (Z:S oversight)
python audit.py

# 3) Run the toy test
python -m pytest -q
```

## Flow
```
[Z:S] spec.glyph.md  --compile-->  pipeline.py  --audit--> report.json
```

If `audit.py` fails, treat it as Z:S rejecting Z:C's implementation.
