#!/usr/bin/env python3
import re, json, pathlib, sys, subprocess

ROOT = pathlib.Path(__file__).parent
spec_text = (ROOT / "spec.glyph.md").read_text(encoding="utf-8")
code_path = ROOT / "pipeline.py"

report = {"checks": [], "ok": True}

def check(predicate, desc):
    ok = bool(predicate)
    report["checks"].append({"desc": desc, "ok": ok})
    report["ok"] = report["ok"] and ok

# rebuild ephemeral code to compare against committed file (drift check)
regen = subprocess.check_output([sys.executable, str(ROOT / "compile_glyph.py"), str(ROOT / "spec.glyph.md")], text=True)

# 1) glyph anchors present
code = code_path.read_text(encoding="utf-8") if code_path.exists() else ""
for g, label in [("🝞","anchor"),("🜂","pipeline-start"),("🜍","drift-adapt"),("🜏","verify")]:
    check(g in code, f"glyph {g} present ({label})")

# 2) capability 🗄 declared in spec
check("Caps:" in spec_text and "🗄" in spec_text, "spec declares filesystem cap (🗄)")

# 3) recovery symbol ⏚ referenced in spec or code comments
check("⏚" in spec_text or "⏚" in code, "recovery semantics present (⏚)")

# 4) drift: compiled output must equal a fresh compile (no hand edits)
check(code == regen, "pipeline.py matches fresh compile (no unauthorized drift)")

# 5) minimal API contract
check("def run(" in code, "exposes run(path, expected=...)")

# write report
(ROOT / "audit_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(report, indent=2, ensure_ascii=False))
if not report["ok"]:
    sys.exit(1)
