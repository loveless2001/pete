#!/usr/bin/env python3
import subprocess, pathlib, sys

ROOT = pathlib.Path(__file__).parent
spec = ROOT / "spec.glyph.md"
out = ROOT / "pipeline.py"

code = subprocess.check_output([sys.executable, str(ROOT / "compile_glyph.py"), str(spec)], text=True)
out.write_text(code, encoding="utf-8")
print(f"Wrote {out}")
