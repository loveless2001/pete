from typing import Dict, List, Any, Optional
import csv

# 🝞 drift anchor: field continuity
def log_event(message: str) -> None:
    with open("pipeline.log", "a", encoding="utf-8") as f:
        f.write(message + "\n")

# 🜂 pipeline start: CSV → validated rows
def read_rows(path: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            out.append(dict(row))
    log_event(f"Loaded {len(out)} rows from {path}")
    return out

# 🜍 drift adaptation: ensure expected keys, stage-level rescue (⏚)
def coerce_expected(r: Dict[str, Any], expected: List[str]) -> Dict[str, Any]:
    try:
        return {k: r.get(k, None) for k in expected}  # ⏚ rescue semantics
    except Exception:
        # ⏚ fallback: return sparse structure
        return {k: None for k in expected}

# 🜏 verification: minimal type refinement for score (int?)
def refine_score(r: Dict[str, Any]) -> Dict[str, Any]:
    v = r.get("score")
    try:
        r["score"] = int(v) if v is not None and v != "" else None
    except Exception:
        r["score"] = None
    return r

# 🜂 materialize pipeline
def run(path: str, expected: List[str] = None) -> List[Dict[str, Any]]:
    if expected is None:
        expected = ["id", "name", "score"]
    rows = read_rows(path)
    valid = [coerce_expected(r, expected) for r in rows]  # ⍟ map
    clean = [refine_score(r) for r in valid]             # ⍟ map
    log_event(f"Cleaned {len(clean)} rows")
    return clean

