Target: Python 3.11
Style: type hints
Caps: 🗄
[GLYPH]
# CSV → validate → clean → write DB, resilient + typed
⟦use py:legacy.csv { read_rows: (str→list[dict])? }⟧
expected ≔ ["id","name","score"]
rows ≔ path · read_rows
valid ≔ rows · ⍟(λr. ⏚( {k:r.get(k,None) for k in expected}, r ))   # ⏚ stage rescue
clean ≔ valid · ⍟(λr. r | {"score": (r["score"]: int?)})            # gradual typing
⤴ clean
[/GLYPH]
