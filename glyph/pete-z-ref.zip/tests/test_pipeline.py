import os, json
from pipeline import run

def test_run_tmp_csv(tmp_path):
    p = tmp_path / "data.csv"
    p.write_text("id,name,score\n1,Alice,10\n2,Bob,\n", encoding="utf-8")
    rows = run(str(p))
    assert len(rows) == 2
    assert set(rows[0].keys()) == {"id","name","score"}
    assert rows[0]["score"] == 10
    assert rows[1]["score"] is None
