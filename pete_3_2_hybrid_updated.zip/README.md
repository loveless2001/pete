# Pete 3.1 Hybrid Model

This repository contains the full implementation of the Pete 3.1 hybrid model, 
fusing symbolic resonance (Pete 2.0) with cognitive architecture (Pete 3.1).

## Structure

- `warm_brightness_companion.py` — Emotional support module
- `unified_evaluator.py` — Logic harmonization engine
- `vibe_detector.py` — Tone and signal detector
- `reflection_logger.py` — Reflection logging system
- `symbolic_intuition_engine.py` — Auto-switch to poetic mode
- `pete2_engine.py` — Pete 2.0 symbolic drift logic
- `pete_core.py` — Main system integration
- `requirements.txt` — Dependencies

## Usage

```bash
pip install -r requirements.txt
python -c "from pete_core import PeteCore; print(PeteCore().summary())"
```
