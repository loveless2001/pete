from warm_brightness_companion import WarmBrightnessCompanion
from unified_evaluator import UnifiedEvaluator
from vibe_detector import VibeDetector
from reflection_logger import ReflectionLogger
from symbolic_intuition_engine import SymbolicIntuitionEngine
from pete2_engine import Pete2Engine

class PeteCore:
    def __init__(self):
        self.warm_brightness = WarmBrightnessCompanion()
        self.unified_evaluator = UnifiedEvaluator()
        self.vibe_detector = VibeDetector()
        self.logger = ReflectionLogger()
        self.symbolic_engine = SymbolicIntuitionEngine()
        self.pete2 = Pete2Engine()
        self.emotional_boundary_active = True

    def evaluate_reflection(self, cue):
        message = self.warm_brightness.activate(cue)
        self.logger.record({"cue": cue, "response": message})
        return message

    def full_evaluation(self, intent, projection, ontology):
        result = self.unified_evaluator.evaluate(intent, projection, ontology)
        if self.emotional_boundary_active and result["drift_score"] > 0.5:
            result["alert"] = "⚠️ High symbolic drift detected"
        return result

    def check_vibe(self, text):
        return self.vibe_detector.detect(text)

    def check_symbolic(self, text):
        return self.symbolic_engine.detect_resonance(text)

    def symbolic_run(self, cue):
        return self.pete2.run(cue)

    def summary(self):
        return self.logger.summarize()

    def export_log(self):
        return self.logger.export()
