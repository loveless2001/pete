class SymbolicIntuitionEngine:
    def should_shift_to_poetic(self, text):
        # Detects emotional ambiguity or symbolic density
        symbolic_keywords = ["feel", "shadow", "echo", "silence", "meaning", "lost", "ghost", "drift", "soul"]
        return any(word in text.lower() for word in symbolic_keywords)

    def detect_resonance(self, text):
        if len(text) < 10:
            return "short impulse"
        elif self.should_shift_to_poetic(text):
            return "symbolic density detected"
        return "neutral"
