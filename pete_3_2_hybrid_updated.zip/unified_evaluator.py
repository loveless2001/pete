class UnifiedEvaluator:
    def evaluate(self, intent, projection, ontology):
        return {
            "intent": intent,
            "projection": projection,
            "ontology": ontology,
            "drift_score": 0.18,
            "reflection_prompt": "Where is the warmth hidden in this?"
        }
