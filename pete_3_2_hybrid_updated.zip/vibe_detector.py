class VibeDetector:
    def detect(self, raw_input):
        if "magic" in raw_input or "TODO" in raw_input:
            return "intuitive marker detected"
        elif len(raw_input) < 8:
            return "possible signal: short code"
        else:
            return "neutral"
